#' Visualization of the matching result
#'
#' This function grabs the information about the matching from 'match_info' variable
#' to visualize the matching. If there is no matching OBDII trip then its title will
#' tell you there is no matching trip.
#'
#' @param target_trip_data A smartphone trip data, it should contain column names "timestamp" and "speed".
#' @param obd2_data A collection of OBDII trip data.
#' @param match_info A list containing matching result from a function "FindBestTrip".
#' @export
VisTrip <- function(target_trip_data, obd2_data, match_info){

    ref_trip_data <- obd2_data[[match_info$macthed_trip]]

    # grab information about the start and end points
    start_p_ref <- match_info$start_index_ref
    end_p_ref <- start_p_ref + match_info$overlap_length - 1

    start_p_tar <- match_info$start_index_tar
    end_p_tar <- start_p_tar + match_info$overlap_length - 1
    # k <- match_info$k

    mydata <- data.frame(timestamp = ref_trip_data$timestamp[start_p_ref:end_p_ref],
                         speed = target_trip_data$speed[start_p_tar:end_p_tar])

    # ref trip data, trip_data both have timestamp, speed
    p <- ggplot2::ggplot(data = ref_trip_data, ggplot2::aes(x = timestamp,
                                              y = speed / 3.6)) +
        ggplot2::geom_line()+
        ggplot2::geom_line(data = mydata, ggplot2::aes(timestamp, speed),
                           col = "red") +
        ggplot2::labs(x = "Time (sec.)",
                      y = "Speed (km/h)") +
        ggplot2::theme(legend.position="none") +
        ggplot2::ylim(0, max(30, max(mydata$speed))) +
        ggplot2::theme_bw()

    # check whether it is the best match or not
    if (match_info$dissimilarity > 0.1 ){
        p <- p + ggplot2::labs(title = "This is not the best matching.")
    }

    p
}


# declare 'timestamp' and 'speed' as global variable.
if(getRversion() >= "2.15.1") {
    utils::globalVariables(c("timestamp", "speed", "dissimilarity", "accuracy"))
}
