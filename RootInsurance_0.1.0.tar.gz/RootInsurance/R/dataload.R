#' Load telematics data.
#'
#' LoadTelematics data uses jsonlite package to load the data
#' from json fomatted telematics data.
#' @param data_path path for the folder containing telematics data
#' @return A list of telematics data. Multiple trips combined as a list,
#' and each components recorded as a data frame.
#' @export
LoadTelematics <- function(data_path){
    jsonlite::fromJSON(data_path, flatten = TRUE)
}
